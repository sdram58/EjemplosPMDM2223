package com.catata.loginbackground.model

data class User(val username:String, val password:String, val age:Int, val name:String)